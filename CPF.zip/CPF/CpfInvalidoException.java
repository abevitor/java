public class CpfInvalidoException  extends Exception{

}
